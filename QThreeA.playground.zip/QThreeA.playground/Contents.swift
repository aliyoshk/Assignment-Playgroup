import UIKit

var msg = "iOS Training Assessment"
var res = msg.replacingOccurrences(of: "a", with: "X")
print(res)
