import UIKit

var txt = "iOS Training Assessment"
var val = txt.replacingOccurrences(of: "sess", with: "")
