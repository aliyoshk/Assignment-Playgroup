import UIKit

var message = "This is Pakistan"
var res = message.replacingOccurrences(of: "is", with: "")
print(res)
