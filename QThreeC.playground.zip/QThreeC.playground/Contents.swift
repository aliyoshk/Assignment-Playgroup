import UIKit

var n1 : Int
var n2 : Int

n1 = 45
n2 = 30

var res = n1 / n2
print(res)

//The answer tend to be INT because all the variable data type where INT and for Int data type, it does hold any floating point value only Natural Numbers
